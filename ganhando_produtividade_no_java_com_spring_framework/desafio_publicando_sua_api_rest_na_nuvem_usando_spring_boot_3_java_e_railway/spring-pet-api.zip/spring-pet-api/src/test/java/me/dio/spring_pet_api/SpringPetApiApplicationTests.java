package me.dio.spring_pet_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringPetApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
