package me.dio.spring_pet_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringPetApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringPetApiApplication.class, args);
	}

}
