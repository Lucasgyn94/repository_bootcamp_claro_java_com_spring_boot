package me.dio.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaRepositoryApplication.class, args);
	}

}
